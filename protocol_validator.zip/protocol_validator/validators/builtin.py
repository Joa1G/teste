"""
Validators atômicos reutilizáveis.

Cada um é uma classe pequena focada em uma única checagem.
Todos são instanciados pelo engine a partir do YAML, via registry.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from engine.core import Validator, ValidationContext, ValidationResult
from engine.registry import register_validator


# ---------------------------------------------------------------------------
# folder_present — verifica que uma pasta existe
# ---------------------------------------------------------------------------
@register_validator("folder_present")
class FolderPresentValidator(Validator):
    """
    YAML:
      - type: folder_present
        name: "raw"                  # nome exato, OU
        pattern: "Y*"                # glob
    """
    def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
        name = self.resolved("name", ctx)
        pattern = self.resolved("pattern", ctx)
        target = name or pattern or "?"

        if name:
            path = ctx.root / name
            if path.is_dir():
                return [ValidationResult(True, self.name, target, f"Pasta '{name}' presente")]
            return [ValidationResult(False, self.name, target, f"Pasta '{name}' ausente em {ctx.root}")]

        if pattern:
            matches = [p for p in ctx.root.glob(pattern) if p.is_dir()]
            if matches:
                return [ValidationResult(True, self.name, target, f"{len(matches)} pasta(s) casando '{pattern}'")]
            return [ValidationResult(False, self.name, target, f"Nenhuma pasta casando '{pattern}' em {ctx.root}")]

        return [ValidationResult(False, self.name, target, "folder_present sem 'name' nem 'pattern'")]


# ---------------------------------------------------------------------------
# file_count — valida quantidade de arquivos casando um glob
# ---------------------------------------------------------------------------
@register_validator("file_count")
class FileCountValidator(Validator):
    """
    YAML:
      - type: file_count
        pattern: "*.csv"
        count: 3                  # exato
        # OU:
        # min: 1
        # max: 5
    """
    def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
        pattern = self.resolved("pattern", ctx, "*")
        target = f"{ctx.root.name}/{pattern}"

        files = [p for p in ctx.root.glob(pattern) if p.is_file()]
        n = len(files)

        expected = self.config.get("count")
        min_n = self.config.get("min")
        max_n = self.config.get("max")

        if expected is not None:
            ok = n == expected
            msg = f"Esperado {expected} arquivo(s) '{pattern}', encontrado {n}"
            return [ValidationResult(ok, self.name, target, msg)]

        if min_n is not None and n < min_n:
            return [ValidationResult(False, self.name, target,
                                     f"Esperado ao menos {min_n} '{pattern}', encontrado {n}")]
        if max_n is not None and n > max_n:
            return [ValidationResult(False, self.name, target,
                                     f"Esperado no máximo {max_n} '{pattern}', encontrado {n}")]

        return [ValidationResult(True, self.name, target, f"{n} arquivo(s) '{pattern}' — ok")]


# ---------------------------------------------------------------------------
# file_size — valida tamanho mínimo/máximo
# ---------------------------------------------------------------------------
@register_validator("file_size")
class FileSizeValidator(Validator):
    """
    YAML:
      - type: file_size
        pattern: "*.csv"
        min_kb: 500
        # max_kb: 10000    (opcional)
    """
    def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
        pattern = self.resolved("pattern", ctx, "*")
        min_kb = self.config.get("min_kb")
        max_kb = self.config.get("max_kb")

        results: list[ValidationResult] = []
        files = [p for p in ctx.root.glob(pattern) if p.is_file()]
        if not files:
            results.append(ValidationResult(
                False, self.name, pattern,
                f"Nenhum arquivo '{pattern}' para checar tamanho",
                severity="warning",
            ))
            return results

        for f in files:
            size_kb = f.stat().st_size / 1024
            if min_kb is not None and size_kb < min_kb:
                results.append(ValidationResult(
                    False, self.name, f.name,
                    f"{f.name}: {size_kb:.1f}KB < mínimo {min_kb}KB",
                    path=str(f.relative_to(ctx.protocol_root)),
                ))
                continue
            if max_kb is not None and size_kb > max_kb:
                results.append(ValidationResult(
                    False, self.name, f.name,
                    f"{f.name}: {size_kb:.1f}KB > máximo {max_kb}KB",
                    path=str(f.relative_to(ctx.protocol_root)),
                ))
                continue
            results.append(ValidationResult(
                True, self.name, f.name,
                f"{f.name}: {size_kb:.1f}KB — ok",
            ))
        return results


# ---------------------------------------------------------------------------
# filename_contains — substring obrigatória no nome
# ---------------------------------------------------------------------------
@register_validator("filename_contains")
class FilenameContainsValidator(Validator):
    """
    YAML:
      - type: filename_contains
        pattern: "*.csv"
        must_contain: "{tag}"
    """
    def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
        pattern = self.resolved("pattern", ctx, "*")
        must = self.resolved("must_contain", ctx, "")

        results: list[ValidationResult] = []
        files = [p for p in ctx.root.glob(pattern) if p.is_file()]
        for f in files:
            ok = must in f.name
            msg = (f"{f.name} contém '{must}'" if ok
                   else f"{f.name} NÃO contém '{must}'")
            results.append(ValidationResult(
                ok, self.name, f.name, msg,
                path=str(f.relative_to(ctx.protocol_root)),
            ))
        return results


# ---------------------------------------------------------------------------
# filename_matches — regex no nome, opcional "capture" para extrair grupo
# ---------------------------------------------------------------------------
@register_validator("filename_matches")
class FilenameMatchesValidator(Validator):
    """
    YAML:
      - type: filename_matches
        pattern: "*.csv"
        regex: '^\\d{8}_\\d{6}_.*\\.csv$'
    """
    def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
        pattern = self.resolved("pattern", ctx, "*")
        regex = self.config.get("regex", "")
        rx = re.compile(regex)

        results: list[ValidationResult] = []
        files = [p for p in ctx.root.glob(pattern) if p.is_file()]
        for f in files:
            ok = bool(rx.match(f.name))
            msg = (f"{f.name} casa /{regex}/" if ok
                   else f"{f.name} NÃO casa /{regex}/")
            results.append(ValidationResult(
                ok, self.name, f.name, msg,
                path=str(f.relative_to(ctx.protocol_root)),
            ))
        return results


# ---------------------------------------------------------------------------
# grouped_files — valida grupos derivados de arquivos-fonte
# ---------------------------------------------------------------------------
@register_validator("grouped_files")
class GroupedFilesValidator(Validator):
    """
    Para cada arquivo "fonte" (ex: raw/*.csv), extrai uma chave do nome
    (via regex com grupo capturador) e valida que existem os arquivos
    esperados no diretório-alvo contendo essa chave.

    YAML:
      - type: grouped_files
        link_source: "raw/*.csv"
        capture_regex: '(\\d{8}_\\d{6})'   # 1º grupo = chave do grupo
        target_root: "."                   # onde procurar o grupo (relativo ao ctx.root)
        expected_groups: 3                 # opcional — quantos grupos esperar
        per_group:
          - pattern: "{key}_*.csv"
            count: 4
          - pattern: "{key}_*.pdf"
            count: 1
    """
    def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
        link_source = self.resolved("link_source", ctx, "")
        capture_regex = self.config.get("capture_regex", "")
        target_root_rel = self.resolved("target_root", ctx, ".")
        expected_groups = self.config.get("expected_groups")
        per_group = self.config.get("per_group", [])

        results: list[ValidationResult] = []
        source_files = sorted(ctx.root.glob(link_source))
        source_files = [f for f in source_files if f.is_file()]

        rx = re.compile(capture_regex)
        keys: list[str] = []
        for f in source_files:
            m = rx.search(f.name)
            if not m:
                results.append(ValidationResult(
                    False, self.name, f.name,
                    f"Fonte '{f.name}' não casa capture_regex /{capture_regex}/",
                ))
                continue
            keys.append(m.group(1))

        # Checa quantidade de grupos
        if expected_groups is not None and len(keys) != expected_groups:
            results.append(ValidationResult(
                False, self.name, link_source,
                f"Esperado {expected_groups} grupo(s), encontrado {len(keys)}",
            ))

        # Checa cada grupo
        target_root = ctx.root / target_root_rel
        for key in keys:
            for rule in per_group:
                pat = rule.get("pattern", "*").format(key=key)
                expected_count = rule.get("count")
                matches = [p for p in target_root.glob(pat) if p.is_file()]
                if expected_count is not None and len(matches) != expected_count:
                    results.append(ValidationResult(
                        False, self.name, f"grupo {key}",
                        f"Grupo '{key}': esperado {expected_count} de '{pat}', "
                        f"encontrado {len(matches)}",
                    ))
                else:
                    results.append(ValidationResult(
                        True, self.name, f"grupo {key}",
                        f"Grupo '{key}': {len(matches)}× '{pat}' — ok",
                    ))

        return results


# ---------------------------------------------------------------------------
# entry_count — conta total de entradas (arquivos + pastas) em um diretório
# ---------------------------------------------------------------------------
@register_validator("entry_count")
class EntryCountValidator(Validator):
    """
    YAML:
      - type: entry_count
        count: 7              # exato
        # OU min / max
    """
    def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
        entries = list(ctx.root.iterdir()) if ctx.root.is_dir() else []
        n = len(entries)
        expected = self.config.get("count")
        min_n = self.config.get("min")
        max_n = self.config.get("max")

        target = ctx.root.name
        if expected is not None:
            ok = n == expected
            extras = ""
            if not ok:
                names = sorted(e.name for e in entries)
                extras = f" [encontrados: {', '.join(names)}]"
            return [ValidationResult(
                ok, self.name, target,
                f"Esperado {expected} entrada(s), encontrado {n}{extras}",
            )]

        if min_n is not None and n < min_n:
            return [ValidationResult(False, self.name, target,
                                     f"Esperado ao menos {min_n} entradas, encontrado {n}")]
        if max_n is not None and n > max_n:
            return [ValidationResult(False, self.name, target,
                                     f"Esperado no máximo {max_n} entradas, encontrado {n}")]
        return [ValidationResult(True, self.name, target, f"{n} entrada(s) — ok")]


# ---------------------------------------------------------------------------
# in_folder — container: entra em uma subpasta (glob ou nome) e roda checks
# ---------------------------------------------------------------------------
@register_validator("in_folder")
class InFolderValidator(Validator):
    """
    Container validator. Resolve uma subpasta via `name` ou `pattern` e
    executa os `checks` aninhados no contexto dessa subpasta.

    Se `pattern` casar múltiplas pastas, os checks rodam em cada uma.

    YAML:
      - type: in_folder
        pattern: "LEFT1_*"       # ou name: "raw"
        required: true           # opcional — falha se nenhuma pasta casar
        checks:
          - type: file_count
            pattern: "*.csv"
            count: 5
    """
    def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
        # import local pra evitar ciclo de import
        from engine.runner import run_checks

        name = self.resolved("name", ctx)
        pattern = self.resolved("pattern", ctx)
        required = self.config.get("required", True)
        nested = self.config.get("checks", [])

        target = name or pattern or "?"
        results: list[ValidationResult] = []

        if name:
            folders = [ctx.root / name] if (ctx.root / name).is_dir() else []
        elif pattern:
            folders = [p for p in ctx.root.glob(pattern) if p.is_dir()]
        else:
            return [ValidationResult(False, self.name, target,
                                     "in_folder sem 'name' nem 'pattern'")]

        if not folders:
            if required:
                results.append(ValidationResult(
                    False, self.name, target,
                    f"Nenhuma pasta casando '{target}' em {ctx.root}",
                ))
            return results

        for folder in sorted(folders):
            child_ctx = ValidationContext(
                root=folder,
                protocol_root=ctx.protocol_root,
                variables=dict(ctx.variables),
            )
            results.extend(run_checks(nested, child_ctx))

        return results
