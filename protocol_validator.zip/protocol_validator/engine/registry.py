"""
Registry de validators.

Cada validator se registra automaticamente via @register_validator("nome").
O engine consulta este registry ao ler o YAML.
"""

from __future__ import annotations

from typing import Type

from .core import Validator


_REGISTRY: dict[str, Type[Validator]] = {}


def register_validator(name: str):
    """
    Decorator que registra uma classe Validator sob um nome.

    Ex:
        @register_validator("file_count")
        class FileCountValidator(Validator):
            ...
    """
    def wrapper(cls: Type[Validator]) -> Type[Validator]:
        if name in _REGISTRY:
            raise ValueError(f"Validator '{name}' já está registrado")
        cls.name = name
        _REGISTRY[name] = cls
        return cls
    return wrapper


def get_validator(name: str) -> Type[Validator]:
    if name not in _REGISTRY:
        raise KeyError(
            f"Validator '{name}' não encontrado. "
            f"Disponíveis: {sorted(_REGISTRY.keys())}"
        )
    return _REGISTRY[name]


def list_validators() -> list[str]:
    return sorted(_REGISTRY.keys())
