"""
Relatório de validação em formato terminal, com cores ANSI.
Sem dependência externa — só stdlib.
"""

from __future__ import annotations

import sys

from engine.runner import ValidationRun


# ANSI colors
class C:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    CYAN = "\033[36m"

    @staticmethod
    def strip() -> None:
        for attr in ("RESET", "BOLD", "DIM", "RED", "GREEN", "YELLOW", "BLUE", "CYAN"):
            setattr(C, attr, "")


def print_report(run: ValidationRun, verbose: bool = False) -> None:
    if not sys.stdout.isatty():
        C.strip()

    print()
    print(f"{C.BOLD}{C.CYAN}═══ Relatório de validação ═══{C.RESET}")
    print(f"  Protocolo: {C.BOLD}{run.protocol}{C.RESET}")
    print(f"  Pasta:     {C.DIM}{run.protocol_folder}{C.RESET}")
    print()

    # --- Nível protocolo ---
    if run.results_protocol:
        print(f"{C.BOLD}[Nível do protocolo]{C.RESET}")
        _print_results(run.results_protocol, verbose)
        print()

    # --- Participantes ---
    if run.results_by_participant:
        print(f"{C.BOLD}[Participantes]{C.RESET}")
        for pkey, results in run.results_by_participant.items():
            fails = [r for r in results if not r.passed]
            status = (f"{C.GREEN}✓ PASS{C.RESET}" if not fails
                      else f"{C.RED}✗ {len(fails)} falha(s){C.RESET}")
            print(f"  {C.BOLD}{pkey}{C.RESET}  {status}")
            if fails or verbose:
                _print_results(results if verbose else fails, verbose, indent="    ")
        print()

    # --- Sumário ---
    total = run.total
    fails = run.failures
    passed = total - fails
    bar_color = C.GREEN if fails == 0 else C.RED
    print(f"{C.BOLD}Sumário:{C.RESET} "
          f"{C.GREEN}{passed} ok{C.RESET}, "
          f"{bar_color}{fails} falha(s){C.RESET}, "
          f"{total} total")
    print()


def _print_results(results, verbose: bool, indent: str = "  ") -> None:
    for r in results:
        if r.passed:
            if verbose:
                icon = f"{C.GREEN}✓{C.RESET}"
                print(f"{indent}{icon} {C.DIM}[{r.validator}]{C.RESET} {r.message}")
        else:
            icon = (f"{C.RED}✗{C.RESET}" if r.severity == "error"
                    else f"{C.YELLOW}⚠{C.RESET}")
            path_suffix = f" {C.DIM}({r.path}){C.RESET}" if r.path else ""
            print(f"{indent}{icon} [{r.validator}] {r.message}{path_suffix}")
