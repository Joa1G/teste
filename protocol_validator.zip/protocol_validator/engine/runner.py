"""
Engine de validação.

Lê um YAML de protocolo, identifica a pasta do protocolo, itera pelos
participantes e roda os validators declarados.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from engine.core import ValidationContext, ValidationResult
from engine.registry import get_validator


@dataclass
class ProtocolSpec:
    """Representação em memória de um YAML de protocolo."""
    protocol: str
    version: int
    device: str
    folder_pattern: str                           # ex: "HDLM_CV_IN_ECGWatch_ECG_*"
    protocol_root_checks: list[dict[str, Any]]    # validators no nível do protocolo
    participant_path_template: str                # ex: "Y{year}/{date}_{tag}"
    participant_path_regex: str                   # ex: "Y(\\d{4})/(\\d{8})_(\\d+)"
    participant_vars: list[str]                   # ex: ["year", "date", "tag"]
    participant_checks: list[dict[str, Any]]      # validators aplicados a cada participante

    @classmethod
    def from_yaml(cls, path: Path) -> "ProtocolSpec":
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        participant = data.get("participant", {})
        path_tmpl = participant.get("path", "")

        # Deriva regex e lista de variáveis do template estilo "Y{year}/{date}_{tag}"
        var_names: list[str] = []
        def _sub(m: re.Match) -> str:
            var_names.append(m.group(1))
            return r"(?P<" + m.group(1) + r">[^/]+)"
        regex = re.sub(r"\{(\w+)\}", _sub, re.escape(path_tmpl).replace(r"\{", "{").replace(r"\}", "}"))

        return cls(
            protocol=data["protocol"],
            version=data.get("version", 1),
            device=data.get("device", ""),
            folder_pattern=data["folder_pattern"],
            protocol_root_checks=data.get("protocol_root", []),
            participant_path_template=path_tmpl,
            participant_path_regex=regex,
            participant_vars=var_names,
            participant_checks=participant.get("checks", []),
        )


@dataclass
class ValidationRun:
    protocol: str
    protocol_folder: Path
    results_by_participant: dict[str, list[ValidationResult]] = field(default_factory=dict)
    results_protocol: list[ValidationResult] = field(default_factory=list)

    @property
    def total(self) -> int:
        n = len(self.results_protocol)
        for rs in self.results_by_participant.values():
            n += len(rs)
        return n

    @property
    def failures(self) -> int:
        n = sum(1 for r in self.results_protocol if not r.passed)
        for rs in self.results_by_participant.values():
            n += sum(1 for r in rs if not r.passed)
        return n


def run_checks(checks: list[dict[str, Any]], ctx: ValidationContext) -> list[ValidationResult]:
    """Instancia e roda uma lista de validators definidos no YAML."""
    out: list[ValidationResult] = []
    for check in checks:
        vtype = check.get("type")
        if not vtype:
            continue
        ValidatorCls = get_validator(vtype)
        validator = ValidatorCls(config=check)
        out.extend(validator.validate(ctx))
    return out


def validate_protocol(spec: ProtocolSpec, data_root: Path) -> ValidationRun:
    """
    Roda todas as validações definidas na spec contra uma pasta raiz
    (ex: &Data_regularOperation).
    """
    # Localiza a pasta do protocolo. Pode ter sufixo de data que muda.
    candidates = sorted(data_root.glob(spec.folder_pattern))
    candidates = [c for c in candidates if c.is_dir()]
    if not candidates:
        raise FileNotFoundError(
            f"Nenhuma pasta casando '{spec.folder_pattern}' em {data_root}"
        )
    # Usa a mais recente (última em ordem alfabética, já que termina em data)
    protocol_folder = candidates[-1]

    run = ValidationRun(protocol=spec.protocol, protocol_folder=protocol_folder)

    # 1) Checks no nível do protocolo
    root_ctx = ValidationContext(
        root=protocol_folder,
        protocol_root=protocol_folder,
        variables={},
    )
    run.results_protocol = run_checks(spec.protocol_root_checks, root_ctx)

    # 2) Descoberta de participantes via template/regex
    #    Varre recursivamente relativo à pasta do protocolo até a profundidade
    #    implícita no template.
    depth = spec.participant_path_template.count("/") + 1
    pattern = "*/" * depth
    participant_paths: list[tuple[Path, dict[str, str]]] = []

    for candidate in protocol_folder.glob(pattern.rstrip("/")):
        if not candidate.is_dir():
            continue
        rel = candidate.relative_to(protocol_folder).as_posix()
        m = re.fullmatch(spec.participant_path_regex, rel)
        if m:
            participant_paths.append((candidate, m.groupdict()))

    # 3) Para cada participante, roda os checks com variáveis resolvidas
    for ppath, pvars in sorted(participant_paths):
        pctx = ValidationContext(
            root=ppath,
            protocol_root=protocol_folder,
            variables=pvars,
        )
        results = run_checks(spec.participant_checks, pctx)
        key = ppath.relative_to(protocol_folder).as_posix()
        run.results_by_participant[key] = results

    return run
