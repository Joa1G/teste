"""
Tipos base do sistema de validação.

- ValidationResult: resultado de uma única checagem.
- ValidationContext: carrega o caminho atual + variáveis resolvidas
  (tag, data, timestamps capturados, etc).
- Validator: classe base abstrata que todo validador herda.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


Severity = str  # "error" | "warning" | "info"


@dataclass
class ValidationResult:
    passed: bool
    validator: str           # nome do validator que rodou (ex: "file_count")
    target: str              # o que foi checado (ex: "raw/*.csv")
    message: str             # descrição legível
    severity: Severity = "error"
    path: str | None = None  # caminho relativo onde o problema ocorreu


@dataclass
class ValidationContext:
    """
    Contexto que é passado para cada validator.

    - root: raiz absoluta sendo validada no momento (ex: a pasta do participante)
    - protocol_root: raiz da pasta do protocolo (ex: .../HDLM_CV_IN_ECGWatch_ECG_20250401)
    - variables: dict de variáveis resolvidas. Ex: {"tag": "00719", "year": "2026"}
    - config: o bloco YAML que definiu este validator (dict)
    """
    root: Path
    protocol_root: Path
    variables: dict[str, Any] = field(default_factory=dict)
    config: dict[str, Any] = field(default_factory=dict)

    def child(self, subpath: str, extra_vars: dict[str, Any] | None = None) -> "ValidationContext":
        """Cria um contexto filho, descendo em uma subpasta."""
        new_vars = {**self.variables, **(extra_vars or {})}
        return ValidationContext(
            root=self.root / subpath,
            protocol_root=self.protocol_root,
            variables=new_vars,
            config=self.config,
        )

    def resolve(self, template: str) -> str:
        """
        Substitui {var} no template pelas variáveis do contexto.
        Ex: "{tag}_*.csv" com tag=00719 -> "00719_*.csv"
        """
        if not isinstance(template, str):
            return template
        try:
            return template.format(**self.variables)
        except KeyError:
            # Se a var não existe, devolve o template como está
            # (útil pra patterns que usam chaves pra regex tipo {8})
            return template


class Validator(ABC):
    """Classe base que todo validator herda."""

    # Nome usado no YAML (definido via @register_validator)
    name: str = ""

    def __init__(self, config: dict[str, Any]):
        self.config = config

    @abstractmethod
    def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
        """
        Executa a validação no contexto dado.
        Retorna uma lista de resultados (pode ser vazia se tudo passou
        silenciosamente, ou conter um passed=True explícito).
        """
        ...

    # Helper comum: resolve patterns com variáveis do contexto
    def resolved(self, key: str, ctx: ValidationContext, default: Any = None) -> Any:
        val = self.config.get(key, default)
        if isinstance(val, str):
            return ctx.resolve(val)
        return val
