# Protocol Validator

Validador declarativo de protocolos de pesquisa clínica.
Cada protocolo é descrito em um YAML; validators atômicos e reutilizáveis
são combinados pelo engine para executar as checagens.

## Estrutura

```
protocol_validator/
├── engine/
│   ├── core.py         # Validator, ValidationContext, ValidationResult
│   ├── registry.py     # decorator @register_validator
│   ├── runner.py       # ProtocolSpec (loader YAML) + validate_protocol
│   └── report.py       # relatório terminal com cores
├── validators/
│   └── builtin.py      # file_count, file_size, filename_*, folder_present,
│                       # grouped_files, entry_count, in_folder
├── protocols/
│   ├── ecg_watch.yaml        # HDLM_CV_IN_ECGWatch_ECG
│   └── fall_detection.yaml   # HDLM_FD_2_IN_FallDetection
├── cli.py              # modo interativo (questionary)
└── main.py             # entry point (dispatcher)
```

## Dependências

```bash
pip install pyyaml questionary colorama
```

- **pyyaml** — leitura de YAML (obrigatório)
- **questionary** — menus interativos (obrigatório para o modo interativo)
- **colorama** — cores ANSI no Windows (opcional mas recomendado)

## Uso

### Modo interativo (recomendado)

```bash
python main.py
```

Abre um menu interativo. Seta pra baixo/cima pra navegar, Enter pra selecionar.

- Lista os protocolos disponíveis (cruzando YAMLs em `protocols/` com pastas
  reais em `DATA_ROOT`)
- Protocolos sem pasta correspondente aparecem desabilitados
- Opção "⚡ Rodar todos os disponíveis" quando há 2 ou mais protocolos presentes
- Pergunta se quer modo verbose
- Após rodar, pergunta se quer rodar outra validação ou sair

**Antes de usar, edite o `DATA_ROOT` no topo de `cli.py`**:

```python
# Windows:
DATA_ROOT = Path(r"C:\caminho\real\para\&Data_regularOperation")

# Linux:
DATA_ROOT = Path("/caminho/real/para/&Data_regularOperation")
```

### Modo direto (para scripts, CI, automação)

```bash
python main.py protocols/ecg_watch.yaml /caminho/para/&Data_regularOperation
python main.py protocols/ecg_watch.yaml /caminho/para/&Data_regularOperation --verbose
```

Exit codes: `0` (tudo ok), `1` (houve falhas), `2` (erro de uso).

## Criar um protocolo novo

1. Crie `protocols/meu_protocolo.yaml` seguindo o esquema de `ecg_watch.yaml`.
2. Se algum validator ainda não existe, crie uma classe em `validators/`
   decorada com `@register_validator("meu_nome")` — ela fica disponível
   automaticamente para qualquer YAML.

## Validators disponíveis

| Nome                | O que faz                                                |
| ------------------- | -------------------------------------------------------- |
| `folder_present`    | Verifica que uma pasta existe (por `name` ou `pattern`)  |
| `file_count`        | Quantidade exata (`count`) ou faixa (`min`/`max`)        |
| `entry_count`       | Quantidade TOTAL de entradas (arquivos + pastas)         |
| `file_size`         | Checa `min_kb`/`max_kb` em arquivos casando um glob      |
| `filename_contains` | Verifica substring obrigatória no nome                   |
| `filename_matches`  | Verifica nome do arquivo contra regex                    |
| `grouped_files`     | Valida grupos de arquivos derivados de uma fonte         |
| `in_folder`         | Container — entra numa subpasta e roda checks aninhados  |

## Variáveis

Dentro do YAML você pode usar `{tag}`, `{date}`, `{year}`, etc. Elas são
extraídas automaticamente do `participant.path` (ex: `"Y{year}/{date}_{tag}"`)
e substituídas nos patterns e mensagens.

Veja `CONTEXT.md` para documentação detalhada da arquitetura.
