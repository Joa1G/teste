"""
Entry point CLI.

Modo interativo (sem argumentos):
    python main.py

Modo direto:
    python main.py <caminho_do_protocolo_yaml> <caminho_do_data_root> [--verbose]

Ex:
    python main.py protocols/ecg_watch.yaml /path/to/&Data_regularOperation
"""

from __future__ import annotations

import sys
from pathlib import Path

# No Windows, habilita ANSI colors no terminal (PowerShell/cmd).
# No Linux/Mac é no-op. Se colorama não estiver instalado, ignora silenciosamente
# (o report.py já detecta e desliga cores se stdout não for TTY).
try:
    import colorama
    colorama.just_fix_windows_console()
except ImportError:
    pass

# Garante que os validators built-in sejam importados e se registrem
import validators.builtin  # noqa: F401

from engine.runner import ProtocolSpec, validate_protocol
from engine.report import print_report


def run_direct(argv: list[str]) -> int:
    """Modo não-interativo: path do YAML e do data root via linha de comando."""
    verbose = "--verbose" in argv or "-v" in argv
    args = [a for a in argv if not a.startswith("-")]

    if len(args) < 2:
        print(__doc__)
        return 2

    yaml_path = Path(args[0])
    data_root = Path(args[1])

    if not yaml_path.is_file():
        print(f"YAML não encontrado: {yaml_path}")
        return 2
    if not data_root.is_dir():
        print(f"Data root não é diretório: {data_root}")
        return 2

    spec = ProtocolSpec.from_yaml(yaml_path)
    run = validate_protocol(spec, data_root)
    print_report(run, verbose=verbose)

    return 0 if run.failures == 0 else 1


def main(argv: list[str]) -> int:
    if not argv:
        # Sem argumentos → modo interativo
        from cli import run_interactive
        return run_interactive()
    return run_direct(argv)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
