"""
CLI interativo.

Rodar sem argumentos entra em modo interativo, guiado por menus.
Rodar com argumentos mantém o modo direto (compatível com scripts/CI).
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import questionary

import validators.builtin  # noqa: F401 — popula o registry via decorators

from engine.runner import ProtocolSpec, validate_protocol, ValidationRun
from engine.report import print_report


# =============================================================================
# CONFIGURAÇÃO
# =============================================================================

# Troque para o caminho real no ambiente de trabalho.
# Ex no Windows: Path(r"C:\caminho\para\&Data_regularOperation")
# Ex no Linux:   Path("/caminho/para/&Data_regularOperation")
DATA_ROOT = Path(r"C:\CAMINHO\AQUI\&Data_regularOperation")

# Pasta onde ficam os YAMLs de protocolo. Resolvido relativo a este arquivo.
PROTOCOLS_DIR = Path(__file__).parent / "protocols"


# =============================================================================
# DESCOBERTA
# =============================================================================

def discover_protocols() -> list[tuple[Path, ProtocolSpec, bool]]:
    """
    Lê todos os YAMLs em protocols/ e verifica, para cada um, se há uma pasta
    casando seu folder_pattern dentro do DATA_ROOT.

    Retorna: lista de (caminho_yaml, spec, presente_no_data_root).
    """
    out: list[tuple[Path, ProtocolSpec, bool]] = []
    for yaml_path in sorted(PROTOCOLS_DIR.glob("*.yaml")):
        try:
            spec = ProtocolSpec.from_yaml(yaml_path)
        except Exception as e:
            print(f"⚠  Ignorando {yaml_path.name}: erro ao ler — {e}")
            continue
        if DATA_ROOT.exists():
            matches = list(DATA_ROOT.glob(spec.folder_pattern))
            present = any(m.is_dir() for m in matches)
        else:
            present = False
        out.append((yaml_path, spec, present))
    return out


# =============================================================================
# MENU
# =============================================================================

def build_choices(protocols: list[tuple[Path, ProtocolSpec, bool]]) -> list[Any]:
    """
    Constrói a lista de opções do menu principal.
    Protocolos presentes aparecem primeiro, ausentes desabilitados no final.
    """
    choices: list[Any] = []

    present = [p for p in protocols if p[2]]
    absent = [p for p in protocols if not p[2]]

    for yaml_path, spec, _ in present:
        # Pega o nome da pasta real pra mostrar ao usuário
        matches = sorted(DATA_ROOT.glob(spec.folder_pattern))
        folder_name = matches[-1].name if matches else "?"
        label = f"{spec.protocol}  ·  {folder_name}"
        choices.append(questionary.Choice(title=label, value=("single", yaml_path)))

    if len(present) >= 2:
        choices.append(questionary.Separator())
        choices.append(questionary.Choice(
            title=f"⚡ Rodar todos os disponíveis ({len(present)})",
            value=("all", None),
        ))

    if absent:
        choices.append(questionary.Separator("── protocolos sem dados no data root ──"))
        for yaml_path, spec, _ in absent:
            choices.append(questionary.Choice(
                title=f"{spec.protocol}  ·  (pasta ausente)",
                value=("unavailable", yaml_path),
                disabled="sem pasta casando o folder_pattern",
            ))

    choices.append(questionary.Separator())
    choices.append(questionary.Choice(title="✕ Sair", value=("exit", None)))
    return choices


# =============================================================================
# EXECUÇÃO
# =============================================================================

def run_single(yaml_path: Path, verbose: bool) -> ValidationRun | None:
    """Roda um YAML e imprime o relatório. Retorna o run pra sumário agregado."""
    try:
        spec = ProtocolSpec.from_yaml(yaml_path)
        run = validate_protocol(spec, DATA_ROOT)
        print_report(run, verbose=verbose)
        return run
    except FileNotFoundError as e:
        print(f"✗ {yaml_path.name}: {e}\n")
        return None
    except Exception as e:
        print(f"✗ {yaml_path.name}: erro inesperado — {e}\n")
        return None


def run_all(protocols: list[tuple[Path, ProtocolSpec, bool]], verbose: bool) -> None:
    """Roda todos os protocolos presentes e imprime um sumário agregado no final."""
    present = [(y, s) for y, s, ok in protocols if ok]
    runs: list[tuple[str, ValidationRun]] = []

    for yaml_path, spec in present:
        print(f"\n▶ {spec.protocol}")
        run = run_single(yaml_path, verbose)
        if run is not None:
            runs.append((spec.protocol, run))

    # Sumário agregado
    print("═" * 60)
    print("SUMÁRIO AGREGADO")
    print("═" * 60)
    total_fails = 0
    total_checks = 0
    for name, run in runs:
        total_fails += run.failures
        total_checks += run.total
        status = "✓ OK" if run.failures == 0 else f"✗ {run.failures} falha(s)"
        print(f"  {name:45s} {status}")
    print("-" * 60)
    print(f"  TOTAL: {total_checks - total_fails}/{total_checks} ok, {total_fails} falha(s)")
    print()


# =============================================================================
# ENTRY POINT INTERATIVO
# =============================================================================

def run_interactive() -> int:
    # Banner + checagem do data root
    questionary.print("═══ Protocol Validator ═══", style="bold fg:cyan")
    questionary.print(f"Data root: {DATA_ROOT}", style="fg:ansigray")

    if not DATA_ROOT.exists():
        questionary.print(
            f"\n⚠  Data root não existe: {DATA_ROOT}\n"
            f"   Edite a constante DATA_ROOT no topo de cli.py.\n",
            style="fg:ansiyellow",
        )
        return 2

    protocols = discover_protocols()
    if not protocols:
        questionary.print(
            f"\n⚠  Nenhum YAML encontrado em {PROTOCOLS_DIR}\n",
            style="fg:ansiyellow",
        )
        return 2

    # Loop principal
    while True:
        # Redescobre a cada iteração (estado do disco pode ter mudado)
        protocols = discover_protocols()
        choices = build_choices(protocols)

        answer = questionary.select(
            "O que validar?",
            choices=choices,
            use_shortcuts=True,
        ).ask()

        if answer is None:
            # Ctrl+C / ESC
            return 0

        action, payload = answer

        if action == "exit":
            return 0

        verbose = questionary.confirm(
            "Modo verbose (mostrar também os checks que passaram)?",
            default=False,
        ).ask()
        if verbose is None:
            return 0

        if action == "single":
            run_single(payload, verbose)
        elif action == "all":
            run_all(protocols, verbose)

        again = questionary.confirm(
            "Rodar outra validação?",
            default=True,
        ).ask()
        if not again:
            return 0
