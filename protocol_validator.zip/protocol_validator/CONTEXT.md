# CONTEXT.md

> Documento de contexto para IAs (Claude, GPT, etc.) e desenvolvedores novos.
> Leia isto antes de propor mudanças. O projeto parece simples, mas tem
> escolhas de design que só fazem sentido depois de entender o porquê.

---

## 1. O que é este projeto

Um **validador declarativo** de protocolos de pesquisa clínica. Um instituto
de pesquisa em saúde executa protocolos (sequências de exercícios) usando
devices (smartwatches, Polar, Garmin, CPET K5, etc.), que geram dados. Após
o processamento no ETL, os dados ficam numa estrutura de pastas, e alguém
precisa validar que a estrutura está correta antes de entregar para o time
de pesquisa.

Cada protocolo tem suas próprias regras (quantas pastas, quantos arquivos,
tamanhos mínimos, padrões de nome, relações entre arquivos). O número de
protocolos cresce com o tempo e cada um pode mudar de versão.

**Objetivo central**: adicionar um protocolo novo deve ser escrever um
arquivo de configuração YAML — não código Python. Só se cai em um padrão
de validação inédito é que se escreve uma classe nova.

## 2. Princípio arquitetural

O sistema separa **o que validar** (declarativo, em YAML) de **como validar**
(imperativo, em Python). Essa separação é sagrada:

- **YAML** (em `protocols/`): descreve a estrutura esperada de um protocolo
  específico. Quem escreve isso conhece os protocolos, não precisa conhecer
  Python a fundo.
- **Validators** (em `validators/builtin.py`): classes pequenas, genéricas,
  reutilizáveis. Cada uma sabe fazer UMA coisa (contar arquivos, verificar
  tamanho, casar regex). Elas são combinadas pelo YAML.
- **Engine** (em `engine/`): fino. Lê o YAML, descobre participantes, chama
  os validators. Não sabe nada sobre protocolos específicos.

Se você se pegar adicionando lógica específica de um protocolo dentro do
engine ou de um validator, **pare** — esse conhecimento deveria estar no
YAML.

## 3. Estrutura do projeto

```
protocol_validator/
├── engine/
│   ├── core.py         # Validator (ABC), ValidationContext, ValidationResult
│   ├── registry.py     # decorator @register_validator + _REGISTRY
│   ├── runner.py       # ProtocolSpec.from_yaml + validate_protocol + run_checks
│   └── report.py       # relatório terminal com cores ANSI
├── validators/
│   └── builtin.py      # todos os validators atômicos
├── protocols/
│   ├── ecg_watch.yaml       # HDLM_CV_IN_ECGWatch_ECG
│   └── fall_detection.yaml  # HDLM_FD_2_IN_FallDetection
├── cli.py              # modo interativo (questionary)
└── main.py             # entry point (dispatcher: interativo se sem args)
```

Dependências: **PyYAML** (obrigatória), **questionary** (modo interativo),
**colorama** (opcional, cores ANSI no Windows).

## 4. Conceitos fundamentais

### 4.1 ValidationContext

O contexto é o que é passado para cada validator quando ele roda. Ele
carrega:

- `root`: caminho absoluto da pasta que está sendo validada AGORA
  (ex: a pasta de um participante, ou uma subpasta aninhada)
- `protocol_root`: raiz da pasta do protocolo (para exibir caminhos relativos)
- `variables`: dict com variáveis resolvidas (ex: `{"tag": "00719", "date": "20260408"}`)
- `config`: o bloco YAML que originou este validator

O `root` muda à medida que descemos a hierarquia (ver `in_folder` abaixo),
mas o `protocol_root` permanece o mesmo durante toda a execução.

### 4.2 ValidationResult

Cada checagem produz um ou mais resultados. Um resultado é:

```python
ValidationResult(
    passed: bool,
    validator: str,       # nome do validator (ex: "file_count")
    target: str,          # o que foi checado
    message: str,         # mensagem legível
    severity: str = "error",  # ou "warning"
    path: str | None = None,  # caminho relativo (opcional)
)
```

Erros são **acumulados** — a validação nunca para no primeiro problema.
Isso é uma decisão de produto: o time precisa ver tudo o que está errado
de uma vez.

### 4.3 Registry

Todo validator tem um nome (string) registrado num dicionário global via
decorator:

```python
@register_validator("file_count")
class FileCountValidator(Validator):
    ...
```

O YAML se refere a validators pelo nome (`type: file_count`). O engine
consulta `_REGISTRY[name]` para achar a classe, instancia e executa.

**Importante**: os validators só existem no registry se o módulo que os
define for importado. `main.py` faz `import validators.builtin` no topo
exatamente por causa disso — a importação é o que dispara os decorators.
Se você criar um arquivo novo de validators, precisa garantir que ele é
importado em algum lugar antes de `validate_protocol` rodar.

## 5. Anatomia de um YAML de protocolo

Estrutura mínima:

```yaml
protocol: HDLM_CV_IN_ECGWatch_ECG         # nome lógico
version: 1                                 # versão do YAML
device: ecg_watch                          # informativo

folder_pattern: "HDLM_CV_IN_ECGWatch_ECG_*"  # glob que acha a pasta do protocolo

protocol_root:                             # checks no nível da pasta do protocolo
  - type: file_count
    pattern: "*.csv"
    count: 1
  - type: folder_present
    pattern: "Y*"

participant:
  path: "Y{year}/{date}_{tag}"             # template que descreve onde vive cada participante
  checks:                                   # checks rodados no contexto de cada participante
    - type: folder_present
      name: "raw"
    # ...
```

### 5.1 O campo `folder_pattern`

É um glob aplicado dentro do `data_root` (o `&Data_regularOperation`).
Vários protocolos têm sufixo de data/versão (`_20250401`, `_v20260205`) que
muda entre iterações. O engine pega o match mais recente por ordem
alfabética (que equivale a cronológica, dado o formato de data).

### 5.2 O campo `participant.path`

Este é o ponto mais sutil do YAML. É um template com chaves — tipo
`"Y{year}/{date}_{tag}"`. O engine faz duas coisas com essa string:

1. **Deriva uma regex com grupos nomeados**: `Y(?P<year>[^/]+)/(?P<date>[^/]+)_(?P<tag>[^/]+)`
2. **Guarda a lista de nomes de variáveis**: `["year", "date", "tag"]`

Durante a execução, o engine varre a pasta do protocolo e, para cada
subpasta candidata, tenta casar com essa regex. Se casar, ele extrai as
variáveis e coloca no `ValidationContext.variables` daquele participante.

Isso é o que faz `{tag}` funcionar como variável dentro dos patterns dos
checks. Quando um validator vê `must_contain: "{tag}"`, ele chama
`ctx.resolve("{tag}")` que substitui pela tag real do participante que
está sendo validado naquele momento.

**Se você adicionar uma variável nova no `path`, ela automaticamente fica
disponível para uso nos checks daquele protocolo.** Não precisa declarar
em lugar nenhum.

### 5.3 Patterns vs nomes literais

Muitos validators aceitam `name` (string exata) OU `pattern` (glob). Use
`name` quando o nome é fixo e o erro deve ser "pasta X ausente", use
`pattern` quando pode variar.

## 6. Validators disponíveis

Todos vivem em `validators/builtin.py`. Cada um tem um docstring com o
formato YAML que aceita — sempre leia o docstring antes de usar.

| Nome | O que faz | Quando usar |
|---|---|---|
| `folder_present` | Verifica que uma pasta existe (por `name` ou `pattern`) | "tem que existir uma pasta X" |
| `file_count` | Conta arquivos casando um glob; aceita `count` exato ou `min`/`max` | "tem que ter N arquivos desse tipo" |
| `entry_count` | Conta TOTAL de entradas (arquivos + pastas) em um diretório | "a pasta tem que ter exatamente N itens, nada a mais" |
| `file_size` | Checa `min_kb`/`max_kb` em arquivos casando um glob | "arquivo tem que ter pelo menos X KB" |
| `filename_contains` | Substring obrigatória no nome | "o nome deve conter a tag" |
| `filename_matches` | Regex no nome completo do arquivo | "o nome segue esse padrão específico" |
| `grouped_files` | Valida grupos de arquivos derivados de arquivos-fonte, via captura regex | "pra cada csv em raw/, espero 4 csvs + 1 pdf com o mesmo timestamp fora de raw/" |
| `in_folder` | **Container**: entra numa subpasta e roda checks aninhados dentro dela | "validar conteúdo dentro de uma pasta cujo nome varia" |

### 6.1 O caso especial: `in_folder`

A maioria dos validators opera no `ctx.root` direto. Mas e quando você
precisa validar conteúdo dentro de uma subpasta cujo nome varia (tipo
`LEFT1_ABC123/` onde o `ABC123` é o model code do device)?

`in_folder` é um **container**: ele não valida nada sozinho, ele recebe
um `pattern`/`name` e uma lista de `checks` aninhados. Quando roda:

1. Resolve a subpasta pelo pattern.
2. Cria um `ValidationContext` **filho**, com `root` apontando pra subpasta,
   mas **mantendo** as variáveis do pai (tag, date, year).
3. Chama `run_checks` recursivamente com os checks aninhados e o contexto
   filho.

É recursão: o mesmo mecanismo que roda os checks do nível do participante
roda os checks dentro do `in_folder`. Isso permite profundidade arbitrária
sem complicar o engine.

Exemplo real (de `fall_detection.yaml`):

```yaml
- type: in_folder
  pattern: "LEFT1_*"
  checks:
    - type: file_count
      pattern: "*"
      count: 6
    - type: file_count
      pattern: "*_fall.csv"
      count: 5
    - type: filename_contains
      pattern: "*_fall.csv"
      must_contain: "{tag}"    # ← aqui a tag vem do contexto do participante,
                                #   propagada pelo in_folder
```

### 6.2 O caso especial: `grouped_files`

Usado quando existem arquivos "fonte" e grupos de arquivos derivados,
ligados por uma chave capturada do nome. No ECG Watch: cada csv em `raw/`
tem um timestamp no nome, e existem 5 arquivos derivados (4 csv + 1 pdf)
compartilhando esse timestamp no nível acima.

A lógica é: lista os arquivos-fonte, extrai a chave via `capture_regex`,
e para cada chave verifica que o número esperado de arquivos casa
`{key}_*.csv` (ou similar) no `target_root`.

## 7. Fluxo de execução completo

```
$ python main.py protocols/ecg_watch.yaml /dados/&Data_regularOperation

  1. main.py importa validators.builtin
     → decorators @register_validator populam _REGISTRY

  2. ProtocolSpec.from_yaml("protocols/ecg_watch.yaml")
     → lê YAML via PyYAML
     → converte participant.path em regex com grupos nomeados
     → retorna objeto ProtocolSpec

  3. validate_protocol(spec, /dados/&Data_regularOperation)
     │
     ├─ A) Acha a pasta do protocolo
     │    glob("HDLM_CV_IN_ECGWatch_ECG_*") → pega a mais recente
     │
     ├─ B) Valida o nível do protocolo
     │    ctx = ValidationContext(root=protocol_folder, variables={})
     │    run_checks(spec.protocol_root_checks, ctx)
     │
     ├─ C) Descobre participantes
     │    Para cada subpasta com profundidade do path template:
     │      tenta casar regex derivada do path
     │      se casar: extrai variáveis (year, date, tag) e guarda
     │
     └─ D) Valida cada participante
          Para cada participante descoberto:
            ctx = ValidationContext(root=ppath, variables={"tag":..., ...})
            run_checks(spec.participant_checks, ctx)

  4. print_report(run)
     → itera pelos resultados, aplica cores ANSI, imprime
     → exit code 0 (ok) ou 1 (houve falhas)
```

### 7.1 `run_checks`: o coração do engine

```python
def run_checks(checks, ctx):
    results = []
    for check in checks:
        vtype = check["type"]
        ValidatorCls = get_validator(vtype)   # consulta o registry
        validator = ValidatorCls(config=check)
        results.extend(validator.validate(ctx))
    return results
```

O engine não sabe **nada** sobre o que cada validator faz. Ele só sabe:
"o YAML disse `type: X`, busca a classe X no registry, instancia, chama
`.validate(ctx)`". Isso é o que torna o sistema extensível sem tocar no
engine.

## 8. Como adicionar coisas novas

### 8.1 Adicionar um protocolo novo

Se os validators existentes cobrem os padrões do protocolo: **só YAML**.

1. Crie `protocols/meu_protocolo.yaml` seguindo o esquema.
2. Defina `folder_pattern`, `participant.path`, e a lista de `checks`.
3. Rode: `python main.py protocols/meu_protocolo.yaml /dados`.

Se cair num padrão inédito (ex: validar que um CSV interno tem uma coluna
específica, comparar campos entre arquivos, etc.): crie um validator novo
primeiro (seção 8.2), depois o YAML.

### 8.2 Adicionar um validator novo

1. No `validators/builtin.py` (ou um arquivo novo em `validators/`), crie
   uma classe que herda de `Validator`:

   ```python
   @register_validator("meu_validator")
   class MeuValidator(Validator):
       """
       YAML:
         - type: meu_validator
           pattern: "..."
           ...
       """
       def validate(self, ctx: ValidationContext) -> list[ValidationResult]:
           pattern = self.resolved("pattern", ctx)
           # ... lógica ...
           return [ValidationResult(passed=True, validator=self.name, ...)]
   ```

2. Se criou em arquivo novo, garanta que ele é importado (adicione um
   `import` em `validators/builtin.py` ou em `main.py`).

3. Use no YAML: `- type: meu_validator`.

**Regras para validators bem comportados**:

- Sempre use `self.resolved(key, ctx)` para ler strings da config — isso
  resolve `{tag}` e outras variáveis automaticamente.
- Nunca levante exceções por dados inválidos. Retorne um `ValidationResult`
  com `passed=False` e uma mensagem útil. Exceções só para bugs reais de
  código.
- Retorne listas vazias só se realmente não há nada a reportar. Em geral,
  reporte pelo menos um resultado (passou ou falhou) por operação.
- Acumule resultados em vez de parar no primeiro erro.
- Se o validator é um **container** (como `in_folder`), importe `run_checks`
  localmente dentro do método para evitar ciclos de import.

## 9. Pontos onde é fácil errar

1. **Esquecer de importar o módulo de validators**. O registry só é
   populado pelos decorators quando o módulo é importado. Se você criar
   `validators/extra.py` e não importar em lugar nenhum, seus validators
   não vão existir em runtime.

2. **Strings do YAML vs strings resolvidas**. `self.config["pattern"]`
   pode conter `{tag}` literal. Use `self.resolved("pattern", ctx)` para
   obter o valor com variáveis substituídas.

3. **Regex em YAML precisa de escape**. Backslashes em YAML são literais,
   mas prefira aspas simples (`'^\d+$'`) para evitar drama com escape.
   Aspas duplas em YAML processam escape sequences; aspas simples não.

4. **Globs não são regex**. `file_count` usa glob (`*.csv`), `filename_matches`
   usa regex. Não confunda.

5. **`entry_count` vs `file_count`**. `file_count` conta arquivos casando
   um glob. `entry_count` conta o total de entradas (arquivos + pastas)
   na raiz do contexto — use quando quiser "exatamente 7 itens, nada a
   mais nem a menos".

6. **Variáveis só são resolvidas em strings da config**. Se você fizer
   algo como `path: "raw/{tag}"` num validator que espera um `Path`,
   passe a string pelo `self.resolved` antes de transformar em Path.

7. **`validate_protocol` pega o match mais recente** do `folder_pattern`.
   Se você tiver `HDLM_..._20250101` e `HDLM_..._20250401` na mesma
   pasta, só o de abril será validado. Isso é intencional — mas se você
   precisar validar histórico, precisará adaptar.

8. **Nunca hard-code regras de um protocolo específico em código Python.**
   Se for específico, vai no YAML. Se for um padrão genérico que pode
   aparecer em outros protocolos, pode virar um validator novo.

## 10. O que está fora do escopo hoje

Coisas que o sistema **não** faz ainda, mas que podem ser adicionadas sem
quebrar nada:

- **Validação cruzada entre arquivos** (ex: sexo no nome do arquivo vs
  sexo dentro de um CSV de metadados). Precisa de um validator novo
  `cross_field` que leia conteúdo de arquivos. Foi mencionado como
  necessidade real em outros protocolos — quando chegar a hora, cria-se.
- **Relatórios em JSON, HTML, etc.** Hoje só terminal. O `ValidationRun`
  é estruturado, então serializar é trivial.
- **Rodar todos os protocolos de uma vez.** Hoje o CLI aceita um YAML por
  execução. Um wrapper simples em `main.py` pode iterar por `protocols/*.yaml`.
- **Validação de conteúdo de CSVs** (colunas, tipos, faixas de valores).
  Seria um validator novo usando pandas ou similar.
- **Versionamento explícito de protocolos.** Hoje o YAML tem um campo
  `version` mas ele não é usado para escolher qual YAML aplicar a qual
  versão de dados. Se as regras mudarem significativamente entre versões,
  mantenha múltiplos YAMLs (ex: `ecg_watch_v1.yaml`, `ecg_watch_v2.yaml`).

## 11. Como rodar e testar localmente

```bash
# Dependência
pip install pyyaml

# Rodar um protocolo
python main.py protocols/ecg_watch.yaml /caminho/para/&Data_regularOperation

# Modo verbose (mostra checks que passaram, não só as falhas)
python main.py protocols/ecg_watch.yaml /caminho/para/&Data_regularOperation --verbose
```

Exit codes: `0` (tudo ok), `1` (houve falhas de validação), `2` (erro de
uso do CLI).

Para testar um validator novo sem dados reais, crie uma árvore de pastas
fake com `mkdir` + `dd if=/dev/zero` (para criar arquivos com tamanho
específico), rode o validator contra ela, e confirme que passes e falhas
aparecem como esperado. Esse foi o método usado para desenvolver os
validators existentes.

## 12. Decisões de design que parecem estranhas mas são intencionais

- **Não há sistema de plugins formal.** Validators se registram por
  decorator e o engine os encontra via um dicionário global. Simples,
  funciona, e evita a complexidade de entry points setuptools ou
  carregamento dinâmico. Se o projeto crescer para múltiplos pacotes,
  isso pode precisar mudar.

- **YAML é resolvido como dict cru, não como objetos tipados.** Cada
  validator recebe o dict do YAML como `config` e acessa os campos
  diretamente. Isso é deliberadamente flexível — adicionar um campo
  novo a um validator não requer mexer em nenhum schema central.

- **Variáveis são interpoladas com `str.format`, não com um engine de
  template.** Isso significa que `{tag}` funciona, mas `{tag:upper}`
  não. Se precisar de transformações, adicione no validator ou pré-compute
  no engine.

- **O engine não valida o YAML contra um schema.** Se você escrever um
  campo errado, só vai descobrir em runtime. Isso é aceitável pelo
  tamanho atual do projeto. Se ficar grande demais, considere adicionar
  pydantic ou um JSON schema.

- **Relatório é string formatada, não estrutura de dados consumida por um
  renderer.** Intencional porque hoje só há terminal. Se surgirem mais
  formatos, refatorar o `print_report` para trabalhar sobre o `ValidationRun`
  estruturado (que já existe) é trivial.

---

**TL;DR para uma IA que vai modificar este projeto**: o engine é fino e
genérico, a inteligência mora no YAML e nos validators. Antes de mexer em
qualquer coisa, leia o YAML do protocolo relevante e o docstring do validator
que você quer mudar. Se estiver tentado a adicionar lógica específica de um
protocolo ao engine, pare — esse é o anti-padrão deste projeto.
